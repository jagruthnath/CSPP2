public class MultiplicationTable
{
    public static void main(String[] a)
    {
        for (int i=0;i<10;i++)
            System.out.println(a[0]+"X"+(i+1)+"="+((i+1)*Integer.parseInt(a[0])));
    }
}
