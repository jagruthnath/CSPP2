#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    printf("Sum of first %d even integers is : %d",n,n*(n+1));
    return 0;
}